package Sample.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Bean.produce;
import DBConnec.function;
import Sample.DTO.*;
import Sample.Dao.cartBean;
import Sample.Dao.detailIncoiceDAO;
import Sample.Dao.invoiceDAO;
import Sample.Entity.detailInvoice;

@WebServlet("/cart")
public class cart extends HttpServlet {
	/**
	 * 
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html;charset=UTF-8");
		String action = req.getParameter("action");
		System.out.println(action);
		if (action.equals("addtocart")) {
			String t = req.getParameter("txtTitle");
			String p = req.getParameter("txtPrice");
			String i = req.getParameter("txtImages");
			String c = req.getParameter("txtCode");
			HttpSession session = req.getSession(true);
			cartBean shop = new cartBean();
			shop = (cartBean) session.getAttribute("SHOP");
			session.setMaxInactiveInterval(5000);
			if (shop == null) {
				shop = new cartBean();
			}
			double price = Double.parseDouble(p);
			produce s = new produce(c, t, price, i);
			produceDTO sp = new produceDTO(s);
			shop.addSanPham(sp);
			session.setAttribute("SHOP", shop);
			RequestDispatcher dispatcher = req.getRequestDispatcher("index.jsp");
			dispatcher.forward(req, resp);

		} else if (action.equals("Xóa")) {
			String[] list = req.getParameterValues("rms");
			if (list != null) {
				HttpSession httpSession = req.getSession();
				if (httpSession != null) {
					cartBean shop = (cartBean) httpSession.getAttribute("SHOP");
					if (shop != null) {
						for (int i = 0; i < list.length; i++) {
							shop.removeSanPham(list[i]);

						}
						httpSession.setAttribute("SHOP", shop);

					}
				}
			}
			RequestDispatcher dispatcher = req.getRequestDispatcher("giohang.jsp");
			dispatcher.forward(req, resp);

		} else if (action.equals("Mua Thêm")) {
			resp.sendRedirect("index.jsp");
		} else if (action.equals("Đặt hàng")) {
			HttpSession session = req.getSession();
			Object oj = session.getAttribute("userNameQuest");
			if (oj == null) {
				resp.sendRedirect("login.jsp");
			} else {

				boolean kq1 = invoiceDAO.insertInvoice((String) session.getAttribute("userNameQuest"));
				if (kq1 == true) {
					String code = req.getParameter("txtCode");
					String title = req.getParameter("txtName");
					String price = req.getParameter("txtPrice");
					String soluong = req.getParameter("txtQuantity");
					String total = req.getParameter("txtTotal");
					function fn = new function();
					int mahdct = fn.AutoID();
					detailInvoice ct = new detailInvoice();
					ct.setQuantity(Integer.parseInt(soluong));
					ct.setTitle(title);
					ct.setPrice(Float.valueOf(price));
					ct.setTotal(Float.parseFloat(total));
					ct.setTrangthai("Đang Xủ Lý");
					boolean kq = detailIncoiceDAO.insertDetailInvoice(Integer.parseInt(code), mahdct, ct);
					if (kq == true) {
						
						session.removeAttribute("SHOP");
						resp.sendRedirect("index.jsp");
						
					} else {
						
						resp.sendRedirect("giohang.jsp");
					}

				}
			}

		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}

}
