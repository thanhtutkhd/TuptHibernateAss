package Sample.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/redirection")
public class Redirection extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(true);
		String action = req.getParameter("view");
		System.out.println(action);
		if (action.equals("qlsanpham")) {
			session.setAttribute("view", 1);
			resp.sendRedirect("admin.jsp?pageid=1");
		} else if (action.equals("qlacount")) {
			session.setAttribute("view", 2);
			resp.sendRedirect("admin.jsp?pageid=1");
		}else if(action.equals("qldanhmuc")) {
			session.setAttribute("view", 3);
			resp.sendRedirect("admin.jsp?pageid=1");
		}
		else if(action.equals("qlhoadon")) {
			session.setAttribute("view", 4);
			resp.sendRedirect("admin.jsp?pageid=1");
		}
	}

}
