package Sample.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Sample.Dao.categoriesDAO;
import Sample.Dao.detailIncoiceDAO;
@WebServlet("/detaiController")
public class detaiController extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	String action = req.getParameter("action");
	
	if (action.equals("Edit")) {
		String txtId = req.getParameter("txtId");
		String txtten = req.getParameter("txtten");
		String txtgia = req.getParameter("txtgia");
		String txtsl = req.getParameter("txtsl");
		String txttong = req.getParameter("txttong");
		String txttt = req.getParameter("txttt");
		req.setAttribute("txtId", txtId);
		req.setAttribute("txtten", txtten);
		req.setAttribute("txtgia", txtgia);
		req.setAttribute("txtsl", txtsl);
		req.setAttribute("txttong", txttong);
		req.setAttribute("txttt", txttt);
		RequestDispatcher dispatcher = req.getRequestDispatcher("editProdue.jsp?view=7");
		dispatcher.forward(req, resp);
	}
	else if (action.equals("Update")) {
		String code = req.getParameter("maUpdate");
		String tt= req.getParameter("TTUpdate");
		boolean kq = detailIncoiceDAO.update(Integer.parseInt(code), tt);
		if(kq == true) {
			resp.sendRedirect("admin.jsp?pageid=1");
		}else {
			System.out.println("lỗi");
		}
}
}
}