package Sample.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Sample.Dao.categoriesDAO;
import Sample.Entity.categories;

@WebServlet("/categoriesController")
public class controllerCategories extends HttpServlet {
	/**
	 * 
	 */


	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = req.getParameter("action");
		String code = req.getParameter("txtId");

		System.out.println(action);
		if (action.equals("Delete")) {
			boolean kq = categoriesDAO.deleteCategories(Integer.parseInt(code));
			if (kq == true) {
				resp.sendRedirect("admin.jsp?pageid=1");
			}

		} else if (action.equals("Thêm Danh Mục")) {
			resp.sendRedirect("editProdue.jsp?view=5");
		} else if (action.equals("ADD")) {
			String name = req.getParameter("txtName");
			String link = req.getParameter("txtLink");
			boolean kq = categoriesDAO.addCategories(link, name);
			if (kq == true) {
				resp.sendRedirect("admin.jsp?pageid=1");
			}
		} else if (action.equals("Edit")) {

			RequestDispatcher dispatcher = req.getRequestDispatcher("editProdue.jsp?view=6&code=" + code);
			dispatcher.forward(req, resp);

		} else if (action.equals("Update")) {
			String name = req.getParameter("nameUpdate");
			String link = req.getParameter("linkUpdate");
			String id = req.getParameter("id");
			boolean kq = categoriesDAO.update(Integer.valueOf(id), name, link);
			if(kq == true) {
				resp.sendRedirect("admin.jsp?pageid=1");
			}else {
				System.out.println("lỗi");
			}
				

		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doPost(req, resp);
	}
}
