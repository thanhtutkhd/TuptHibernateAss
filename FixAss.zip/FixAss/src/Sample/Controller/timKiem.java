package Sample.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Sample.Dao.produceDAO;
import Sample.Entity.produce;

@WebServlet("/timKiem")
public class timKiem extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("UTF-8");
		String tensp = req.getParameter("key");
		String action = req.getParameter("action");
		String danhmuc = req.getParameter("chon");
		if (action.equals("Tìm Kiếm")) {

			List<produce> ketqua = produceDAO.seachSanPham(tensp, danhmuc);
			if (ketqua.size() > 0) {
				req.setAttribute("listKetQua", ketqua);
				RequestDispatcher dispatcher = req.getRequestDispatcher("timkiem.jsp");
				dispatcher.forward(req, resp);
			} else {
				req.setAttribute("sss", "Không tìm thấy kết quả");
				RequestDispatcher dispatcher = req.getRequestDispatcher("timkiem.jsp");
				dispatcher.forward(req, resp);
			}
		}else if(action.equals("Seach")) {
			RequestDispatcher dispatcher = req.getRequestDispatcher("admin.jsp?pageid=1");
			dispatcher.forward(req, resp);
		}

	}
}
