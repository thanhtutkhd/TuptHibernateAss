package Sample.Controller;

import org.hibernate.Session;

import Sample.Dao.invoiceDAO;
import Sample.Entity.customer;
import Sample.Entity.invoice;
import Sample.Entity.produce;
import Sample.Util.hibernateUtil;

public class teest {
public static void main(String[] args) {
//	invoice invoice = new invoice();
//	customer cat = new customer();
//	cat.getUsname()
//	invoice.setCustomer(customer);
//	boolean kq = invoiceDAO.insertInvoice("vanquan");
//	
//	if(kq == true) {
//		System.out.println("thành cônng");
//	}else {
//		System.out.println("thất bại");
//	}
	Session session = hibernateUtil.getSessionFactory().openSession();
	session.getTransaction().begin();
	produce sanpham = (produce) session.get(produce.class, 1);
	//System.out.println(sanpham.getCode());
	
	session.getTransaction().commit();
	session.close();
	System.out.println(sanpham.getPrice());
	System.out.println(sanpham.getTitle());
}
}
