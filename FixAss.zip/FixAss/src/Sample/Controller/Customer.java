package Sample.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Sample.Dao.customerDAO;

@WebServlet("/controllerCustomer")
public class Customer extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("UTF-8");
		/// lấy giá trị tài khoản của quest
		String action = req.getParameter("action");
		String us = req.getParameter("txtUserName");
		HttpSession session = req.getSession();
		System.out.println(action);
		System.out.println(us);
		if (action.equals("questUpdate")) {
			String fullname = req.getParameter("txtFullName");
			String diachi = req.getParameter("txtDiaChi");
			String email = req.getParameter("txtEmail");
			String sdt = req.getParameter("txtSdt");
			String pass = req.getParameter("txtPassWord");

			boolean kq = customerDAO.updateAcountQuest(us, fullname, pass, diachi, sdt, email);
			if (kq == true) {
				System.out.println("cập nhập thành công");
				resp.sendRedirect("index.jsp");

			} else {
				System.out.println("Câp nhật thất bạn");
			}
		} else if (action.equals("Delete")) {
			boolean kq = customerDAO.deleteAcount(us);
			if (kq == true) {
				resp.sendRedirect("admin.jsp?pageid=1");

			}
		} else if (action.equals("Edit")) {
			String txtUserName = req.getParameter("txtUserName");
			String txtFullName = req.getParameter("txtFullName");
			String txtDiaChi = req.getParameter("txtDiaChi");
			String txtEmail = req.getParameter("txtEmail");
			String txtSdt = req.getParameter("txtSdt");
			String txtPass = req.getParameter("txtPass");
			String txtisAdmin = req.getParameter("txtisAdmin");
			req.setAttribute("txtUserName", txtUserName);
			req.setAttribute("txtFullName", txtFullName);
			req.setAttribute("txtDiaChi", txtDiaChi);
			req.setAttribute("txtEmail", txtEmail);
			req.setAttribute("txtSdt", txtSdt);
			req.setAttribute("txtPass", txtPass);
			req.setAttribute("txtisAdmin", txtisAdmin);
			RequestDispatcher dispatcher = req.getRequestDispatcher("editProdue.jsp?view=3");
			dispatcher.forward(req, resp);
		}

		else if (action.equals("Update")) {
			String userNameUpdate = req.getParameter("userNameUpdate");
			String fullNameUpdate = req.getParameter("fullNameUpdate");
			String passWordUpdate = req.getParameter("passWordUpdate");
			String emailUpdate = req.getParameter("emailUpdate");
			String sdtUpdate = req.getParameter("sdtUpdate");
			String diaChiUpdate = req.getParameter("diaChiUpdate");
			String roleUpdate = req.getParameter("roleUpdate");
			boolean kq = customerDAO.updateAcount(userNameUpdate, fullNameUpdate, passWordUpdate, diaChiUpdate,
					sdtUpdate, emailUpdate, Integer.parseInt(roleUpdate));
			if (kq == true) {
				resp.sendRedirect("admin.jsp?pageid=1");

			}
		} else if (action.equals("Thêm Tài Khoản")) {
			resp.sendRedirect("editProdue.jsp?view=4");

		} else if (action.equals("ADD")) {
			String username2 = req.getParameter("txtUserName");
			String pass2 = req.getParameter("txtPass");
			String fullname2 = req.getParameter("txtFullName");
			String diachi2 = req.getParameter("txtDiaChi");
			String email2 = req.getParameter("txtEmail");
			String sdt2 = req.getParameter("txtSdt");
			String admin2 = req.getParameter("txtisAdmin");
			boolean kq = customerDAO.insertAcountAdmin(username2, pass2, fullname2, diachi2, sdt2, email2,
					Integer.parseInt(admin2));
			if (kq == true) {
				resp.sendRedirect("admin.jsp?pageid=1");
			} else {
				req.setAttribute("kq", "User Name đã tồn tại");
				RequestDispatcher dispatcher = req.getRequestDispatcher("editProdue.jsp?view=4");
				dispatcher.forward(req, resp);
			}
		} else if (action.equals("Back")) {
			resp.sendRedirect("admin.jsp?pageid=1");
		}

	}
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

}
