package Sample.Dao;

import org.hibernate.Session;

import Sample.Entity.customer;
import Sample.Entity.invoice;
import Sample.Util.hibernateUtil;

public class invoiceDAO {
	public static boolean insertInvoice(String userName) {
		Session session = hibernateUtil.getSessionFactory().openSession();
		try {
			session.getTransaction().begin();
			invoice invoice = new invoice();
			// lấy thông tin khách hàng theo khóa chính(username)
			customer cus = (customer) session.get(customer.class, userName);
			// add thông tin vừa lấy được vào hóa đơn
			cus.getInvoices().add(invoice);
			session.save(invoice);
			session.getTransaction().commit();
			session.close();
			return true;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;

	}

}
