package Sample.Dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import Sample.Entity.categories;
import Sample.Entity.customer;
import Sample.Util.hibernateUtil;

public class categoriesDAO {
	public static List<categories> listCategories() {
		List<categories> lisCategories = null;
		Session session = hibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		String hql = "FROM categories";
		Query query = session.createQuery(hql);
		lisCategories = query.list();
		session.close();
		return lisCategories;

	}

	public static List<categories> listCategoriesPapination(int min, int max) {
		List<categories> lisCategories = null;
		Session session = hibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		String hql = "FROM categories";
		Query query = session.createQuery(hql);
		query.setFirstResult(min);
		query.setMaxResults(max);
		lisCategories = query.list();
		session.close();
		return lisCategories;

	}

	public static categories listCategories(int code) {
		Session session = hibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		categories cs = (categories) session.get(categories.class, code);
		session.close();
		return cs;

	}

	public static boolean addCategories(String link, String name) {
		Session session = hibernateUtil.getSessionFactory().openSession();

		try {
			session.getTransaction().begin();
			categories cr = new categories();
			cr.setLink(link);
			cr.setName(name);
			session.save(cr);
			session.getTransaction().commit();
			session.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();

		}
		return false;
	}

	public static boolean deleteCategories(int code) {
		Session session = hibernateUtil.getSessionFactory().openSession();
		try {
			session.getTransaction().begin();
			categories cate = (categories) session.get(categories.class, code);
			session.delete(cate);
			session.getTransaction().commit();
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return false;
	}

	public static boolean update(int code, String name, String link) {
		Session session = hibernateUtil.getSessionFactory().openSession();
		try {
			session.getTransaction().begin();
			categories cate = (categories) session.get(categories.class, code);
			cate.setLink(link);
			cate.setName(name);
			session.update(cate);
			session.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
}
