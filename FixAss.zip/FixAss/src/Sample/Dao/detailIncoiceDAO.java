package Sample.Dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import Sample.Entity.customer;
import Sample.Entity.detailInvoice;
import Sample.Entity.invoice;
import Sample.Entity.produce;
import Sample.Util.hibernateUtil;

public class detailIncoiceDAO {
	public static List<detailInvoice> getList(int min, int max) {
		List<detailInvoice> list = null;
		Session session = hibernateUtil.openSession();
		try {
			session.getTransaction().begin();
			String hql = " FROM detailInvoice  ";
			Query query = session.createQuery(hql);
			query.setFirstResult(min);
			query.setMaxResults(max);
			list = query.list();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;

	}
	
	
	
	public static boolean insertDetailInvoice(int code, int mahd, detailInvoice hoadonct) {
		Session session = hibernateUtil.getSessionFactory().openSession();
		try {
			session.getTransaction().begin();
			invoice invoi = (invoice) session.get(invoice.class, mahd);
			produce sanpham = (produce) session.get(produce.class, code);
			
			sanpham.getDetailInvoices().add(hoadonct);
			invoi.getDetailInvoices().add(hoadonct);
			session.save(hoadonct);
			session.getTransaction().commit();
			session.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;

	}
	
	public static boolean update(int code, String TT) {
		SessionFactory sessionFactory = hibernateUtil.getSessionFactory();
		Session session = sessionFactory.getCurrentSession();

		try {
			session.getTransaction().begin();
			detailInvoice cs = (detailInvoice) session.get(detailInvoice.class, code);
			cs.setTrangthai(TT);
			session.update(cs);
			session.getTransaction().commit();
			return true;
		} catch (Exception e) {
			if (session.getTransaction() != null) {
				session.getTransaction().rollback();
			}
			e.printStackTrace();
		}
		return false;
	}
	

}
