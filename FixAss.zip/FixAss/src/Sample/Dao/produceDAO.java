package Sample.Dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import Sample.Entity.categories;
import Sample.Entity.customer;
import Sample.Entity.produce;
import Sample.Util.hibernateUtil;

public class produceDAO {
	// LẤY TOÀN BỘ THÔNG TIN CỦA MỘT SẢN PHẨM THEO MÃ DANH MỤC VÀ SỐ LƯỢNG SẢN PHẨM
	public static List<produce> getListProduce2(int sl, String madm) {
		SessionFactory sessionFactory = hibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		List<produce> listt = null;
		try {

			session.getTransaction().begin();
			String sql = " from produce";
			if (madm.length() > 0) {
				sql += " WHERE categories = " + madm;
			}
			Query query = session.createQuery(sql);
			query.setMaxResults(sl);
			listt = query.list();
			session.getTransaction().commit();

		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			session.close();
		}
		return listt;
	}

	// CHÈN MỘT SẢN PHẨM MỚi
	public static boolean insertProduce(produce sp, int ID) {
		Session session = hibernateUtil.getSessionFactory().openSession();
		try {
			session.getTransaction().begin();
			categories cate = (categories) session.get(categories.class, ID);
			cate.getProduces().add(sp);
			session.save(sp);
			session.flush();
			session.getTransaction().commit();
			return true;

		} catch (Exception e) {
			if (session.getTransaction() != null) {
				session.getTransaction().rollback();
				return false;
			}
			e.printStackTrace();
		} finally {
			session.close();
		}
		return false;
	}

	// tìm kiếm sản phẩm theo tên vừa sửa
	public static List<produce> seachSanPham(String tensp, String madanhmuc) {
		List<produce> sp = null;
		SessionFactory sessionFactory = hibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		String sql = " from produce ";
		if (!tensp.equals("") && madanhmuc.equals("")) {
			sql += "where title like  '%" + tensp + "%'";
		}
		if (madanhmuc.length() > 0 && tensp.equals("")) {
			sql += " where categories = " + madanhmuc;
		}
		if (!tensp.equals("") && !madanhmuc.equals("")) {
			sql += "where  title like  '%" + tensp + "%' and categories = " + madanhmuc;
		}
		Query query = session.createQuery(sql);
		sp = query.list();
		session.close();
		return sp;
	}
	public static List<produce> seachSanPhamPapination(String tensp, int MIN , int MAX) {
		List<produce> sp = null;
		SessionFactory sessionFactory = hibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		String sql = " from produce ";
		if (!tensp.equals("")) {
			sql += "where title like  '%" + tensp + "%'";
		}
		Query query = session.createQuery(sql);
		query.setFirstResult(MIN);
		query.setMaxResults(MAX);
		sp = query.list();
		session.close();
		return sp;
	}

	// Lấy thông tin sản phẩm theo mã sản phẩm
	public static produce getInforProdece(int code) {
		Session session = hibernateUtil.getSessionFactory().openSession();
		session.getTransaction().begin();
		produce infor = (produce) session.get(produce.class, code);
		session.close();
		return infor;
	}

	// Xóa sản phẩm them mã sản phẩm
	public static boolean deleteProduce(int code) {
		SessionFactory sessionFactory = hibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		try {
			session.getTransaction().begin();
			produce infor = (produce) session.get(produce.class, code);
			session.delete(infor);
			session.getTransaction().commit();

			return true;
		} catch (Exception e) {
			if (session.getTransaction() != null) {
				session.getTransaction().rollback();
			}
			e.printStackTrace();

		} finally {
			session.close();

		}
		return false;

	}

	// Cập nhập thông tin sản phẩm
	public static boolean updateProduce(int masp, String title, String hinhanh, float gia) {
		Session session = hibernateUtil.openSession();
		try {
			session.getTransaction().begin();
			produce sp = (produce) session.get(produce.class, masp);
			sp.setTitle(title);
			sp.setImages(hinhanh);
			sp.setPrice(gia);
			session.update(sp);
			session.getTransaction().commit();
			return true;
		} catch (Exception e) {
			if (session.getTransaction() != null) {
				session.getTransaction().rollback();
			}
		} finally {
			session.close();
		}
		return false;
	}

	// LẤY SẢN PHẨM THEO KHOẢNG GIÁ TRỊ ==> PHÂN TRANG
	public static List<produce> getListProducePagenation(int MIN, int MAX, String madm) {
		SessionFactory sessionFactory = hibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		List<produce> listt = null;
		try {
			session.getTransaction().begin();
			String sql = " from produce";
			if (madm.length() > 0) {
				sql += " WHERE categories = " + madm;
			}
			Query query = session.createQuery(sql);
			query.setFirstResult(MIN);
			query.setMaxResults(MAX);
			listt = query.list();
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return listt;
	}

}
