package Sample.Dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import Sample.Entity.customer;

import Sample.Util.hibernateUtil;

public class customerDAO {
	// LẤY TOÀN BỘ THÔNG TIN CÁC ACCUONT
	public static List<customer> getListAcount(int min, int max) {
		List<customer> listAcount = null;
		Session session = hibernateUtil.openSession();
		try {
			session.getTransaction().begin();
			String hql = " FROM customer  ";
			Query query = session.createQuery(hql);
			query.setFirstResult(min);
			query.setMaxResults(max);
			listAcount = query.list();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return listAcount;

	}

	// LẤY TOÀN BỘ THÔNG TIN CÁC ACCUONT
	public static List<customer> getListAcount(String userName) {
		List<customer> listAcount = null;
		Session session = hibernateUtil.openSession();
		session.getTransaction().begin();
		String hql = " FROM customer  ";
		if (userName.length() > 0) {
			hql += " where usname = " + userName;
		}
		Query query = session.createQuery(hql);
		listAcount = query.list();

		return listAcount;
	}

	// PHƯƠNG THỨC KIỂM TRA TÍNH HỢP LỆ CỦA USER VÀ TRẢ VỀ QUYỀN TRUY CẬP
	public static int checkLogIn(String userName, String passWord) {
		int role = -1;
		List<customer> list = null;
		Session session = hibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		String sql = "  from customer where usname = '" + userName + "' and pass = '" + passWord + "'";
		Query query = session.createQuery(sql);
		list = query.list();
		if (list.size() > 0) {
			for (customer x : list) {
				return role = x.getIsAdmin();

			}
		}
		session.close();

		return role;

	}

	// PHƯƠNG THỨC LẤY THÔNG TIN CỦA KHÁCH HÀNG THÔNG QUA USER NAME
	public static customer getInforCustomer(String userName) {
		Session session = hibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		customer infor = (customer) session.get(customer.class, userName);
		session.close();
		return infor;

	}
	// THÊM MỘT ACCUONT VÀO CSDL QUYỀN CỦA KHÁCH HÀNG

	public static boolean insertAcount(String userName, String passWord, String fullname, int role) {

		SessionFactory sessionFactory = hibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		if (session.get(customer.class, userName) != null) {
			return false;
		}
		try {
			customer bj = new customer(userName, passWord, fullname, role);
			session.getTransaction().begin();
			session.save(bj);
			session.getTransaction().commit();
			session.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;

	}

	// THÊM MỘT ACCUONT VÀO CSDL QUYỀN CỦA ADMIN
	public static boolean insertAcountAdmin(String userName, String passWord, String fullname, String diachi,
			String sdt, String email, int role) {

		SessionFactory sessionFactory = hibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		if (session.get(customer.class, userName) != null) {
			return false;
		}
		try {
			customer bj = new customer(userName, passWord, fullname, role, diachi, sdt, email);
			session.getTransaction().begin();
			session.save(bj);
			session.getTransaction().commit();
			session.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

	// CẬP NHẬP THÔNG TIN TÀI KHOẢN QUYỀN CỦA ADMIN
	public static boolean updateAcount(String usname, String fullname, String pass, String diachi, String sdt,
			String email, int isAdmin) {
		SessionFactory sessionFactory = hibernateUtil.getSessionFactory();
		Session session = sessionFactory.getCurrentSession();

		try {
			session.getTransaction().begin();
			customer cs = (customer) session.get(customer.class, usname);
			cs.setFullname(fullname);
			cs.setPass(pass);
			cs.setDiachi(diachi);
			cs.setSdt(sdt);
			cs.setEmail(email);
			cs.setIsAdmin(isAdmin);
			session.update(cs);
			session.getTransaction().commit();
			return true;
		} catch (Exception e) {
			if (session.getTransaction() != null) {
				session.getTransaction().rollback();
			}
			e.printStackTrace();
		}
		return false;
	}

	// CẬP NHẬP THÔNG TIN TÀI KHOẢN QUYỀN CỦA KHÁCH HÀNG
	public static boolean updateAcountQuest(String usname, String fullname, String pass, String diachi, String sdt,
			String email) {
		SessionFactory sessionFactory = hibernateUtil.getSessionFactory();
		Session session = sessionFactory.getCurrentSession();
		try {
			session.getTransaction().begin();
			customer cs = (customer) session.get(customer.class, usname);
			cs.setFullname(fullname);
			cs.setPass(pass);
			cs.setDiachi(diachi);
			cs.setSdt(sdt);
			cs.setEmail(email);
			session.update(cs);
			session.getTransaction().commit();
			return true;
		} catch (Exception e) {
			if (session.getTransaction() != null) {
				session.getTransaction().rollback();
			}
			e.printStackTrace();
		}
		return false;
	}

	// Xóa một acuont
	public static boolean deleteAcount(String usName) {
		SessionFactory sessionFactory = hibernateUtil.getSessionFactory();
		Session session = sessionFactory.getCurrentSession();

		try {
			session.beginTransaction();
			customer cs = (customer) session.get(customer.class, usName);
			session.delete(cs);
			session.getTransaction().commit();
			return true;
		} catch (Exception e) {
			if (session.beginTransaction() != null) {
				session.beginTransaction().rollback();

			}
			return false;
		}

	}



}
