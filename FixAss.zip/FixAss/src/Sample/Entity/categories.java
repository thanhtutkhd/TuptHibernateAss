
package Sample.Entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class categories implements Serializable {

	private int id;
	private String name;
	private String link;
	private Set<produce> produces = new HashSet<produce>(0);

	public categories() {
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public categories(String name) {
		this.name = name;
	}

	public categories(int id) {
		this.id = id;
	}

	public categories(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public categories(int id, String name, String link) {
		this.id = id;
		this.name = name;
		this.link = link;
	}

	public categories(int id, String name, String link, Set<produce> produces) {
		this.id = id;
		this.name = name;
		this.produces = produces;
		this.link = link;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<produce> getProduces() {
		return this.produces;
	}

	public void setProduces(Set<produce> produces) {
		this.produces = produces;
	}

}
