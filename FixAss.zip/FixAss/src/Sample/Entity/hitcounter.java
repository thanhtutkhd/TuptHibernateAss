package Sample.Entity;

import java.io.Serializable;

public class hitcounter implements Serializable {
	private int tong;
	private int id;

	public int getTong() {
		return tong;
	}
	

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public void setTong(int tong) {
		this.tong = tong;
	}
	
public hitcounter() {
	// TODO Auto-generated constructor stub
}
public hitcounter(int tong ,int id) {
	this.tong = tong;
	this.id=id;
	// TODO Auto-generated constructor stub
}
}
